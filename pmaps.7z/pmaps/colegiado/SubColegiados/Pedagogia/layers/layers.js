var baseLayer = new ol.layer.Group({
    'title': '',
    layers: [
new ol.layer.Tile({
    'title': 'Thunderforest Landscape',
    'type': 'base',
    source: new ol.source.XYZ({
        url: 'http://tile.thunderforest.com/landscape/{z}/{x}/{y}.png',
        attributions: [new ol.Attribution({html: '&copy; <a href="http://www.opencyclemap.org">OpenCycleMap</a>,&copy; <a href="http://openstreetmap.org">OpenStreetMap</a> contributors,<a href="http://creativecommons.org/licenses/by-sa/2.0/">CC-BY-SA</a>'})]
    })
})
]
});
var format_Pedagogia_0 = new ol.format.GeoJSON();
var features_Pedagogia_0 = format_Pedagogia_0.readFeatures(json_Pedagogia_0, 
            {dataProjection: 'EPSG:4326', featureProjection: 'EPSG:3857'});
var jsonSource_Pedagogia_0 = new ol.source.Vector({
    attributions: [new ol.Attribution({html: '<a href=""></a>'})],
});
jsonSource_Pedagogia_0.addFeatures(features_Pedagogia_0);var lyr_Pedagogia_0 = new ol.layer.Vector({
                source:jsonSource_Pedagogia_0, 
                style: style_Pedagogia_0,
                title: 'Pedagogia<br />\
        <img src="styles/legend/Pedagogia_0_0.png" /> CARMEM WALDOW<br />\
        <img src="styles/legend/Pedagogia_0_1.png" /> CARMEM WALDOW, LEANDRO TURMENA<br />\
        <img src="styles/legend/Pedagogia_0_2.png" /> JUSSARA ISABEL STOCKMANNS<br />\
        <img src="styles/legend/Pedagogia_0_3.png" /> JUSSARA ISABEL STOCKMANNS, DAIANE PADULA PAZ<br />\
        <img src="styles/legend/Pedagogia_0_4.png" /> JUSSARA ISABEL STOCKMANNS, ROBERTO CARLOS BIANCHI<br />\
        <img src="styles/legend/Pedagogia_0_5.png" /> MARCIA DE CAMPOS BIEZEKI<br />\
        <img src="styles/legend/Pedagogia_0_6.png" /> VANIA MARIA ALVES<br />\
        <img src="styles/legend/Pedagogia_0_7.png" /> VANIA MARIA ALVES, CARMEM WALDOW<br />\
        <img src="styles/legend/Pedagogia_0_8.png" /> VANIA MARIA ALVES, LEANDRO TURMENA<br />'
            });

lyr_Pedagogia_0.setVisible(true);
var layersList = [baseLayer,lyr_Pedagogia_0];
lyr_Pedagogia_0.set('fieldAliases', {'id_pesq': 'id_pesq', 'titulo': 'titulo', 'agrupador': 'agrupador', 'producao': 'producao', 'subtipo': 'subtipo', 'ano': 'ano', 'autores': 'autores', 'autor1': 'autor1', 'desc_col': 'desc_col', 'desc_sub': 'desc_sub', 'cdcapes_su': 'cdcapes_su', 'desc_area': 'desc_area', 'cdcapes_ar': 'cdcapes_ar', 'nome_event': 'nome_event', 'nm_localid': 'nm_localid', });
lyr_Pedagogia_0.set('fieldImages', {'id_pesq': 'TextEdit', 'titulo': 'TextEdit', 'agrupador': 'TextEdit', 'producao': 'TextEdit', 'subtipo': 'TextEdit', 'ano': 'TextEdit', 'autores': 'TextEdit', 'autor1': 'TextEdit', 'desc_col': 'TextEdit', 'desc_sub': 'TextEdit', 'cdcapes_su': 'TextEdit', 'desc_area': 'TextEdit', 'cdcapes_ar': 'TextEdit', 'nome_event': 'TextEdit', 'nm_localid': 'TextEdit', });
lyr_Pedagogia_0.set('fieldLabels', {'id_pesq': 'no label', 'titulo': 'no label', 'agrupador': 'no label', 'producao': 'no label', 'subtipo': 'no label', 'ano': 'no label', 'autores': 'no label', 'autor1': 'no label', 'desc_col': 'no label', 'desc_sub': 'no label', 'cdcapes_su': 'no label', 'desc_area': 'no label', 'cdcapes_ar': 'no label', 'nome_event': 'no label', 'nm_localid': 'no label', });
lyr_Pedagogia_0.on('precompose', function(evt) {
    evt.context.globalCompositeOperation = 'normal';
});
    lyr_Pedagogia_0.on("postcompose", update);

    var listenerKey = lyr_Pedagogia_0.on('change', function(e) {
        update();
        ol.Observable.unByKey(listenerKey);
    });