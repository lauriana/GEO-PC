var json_Producao_0 = {
"type": "FeatureCollection",
"crs": { "type": "name", "properties": { "name": "urn:ogc:def:crs:OGC:1.3:CRS84" } },
"features": [
{ "type": "Feature", "properties": { "id_pesq": "441", "titulo": "PARTICIPANTE DO DOCUMENTARIO 'A CHAMA DA LINGUA - UM VIDEOREQUIEM'", "agrupador": "PRODUCAO ARTISTICA\/CULTURAL", "producao": "OUTRA PRODUCAO ARTISTICA\/CULTURAL", "subtipo": "NAO INFORMADO", "ano": 2016.0, "autores": "JACOB DOS SANTOS BIZIAK", "autor1": "JACOB DOS SANTOS BIZIAK", "desc_col": "LETRAS PORTUGUES\/INGLES", "desc_sub": "LETRAS", "cdcapes_su": 80200001.0, "desc_area": "LINGUISTICA, LETRAS E ARTES", "cdcapes_ar": 80000002.0, "nome_event": null, "nm_localid": "RIBEIRÃO PRETO" }, "geometry": { "type": "MultiPoint", "coordinates": [ [ -47.805475915541521, -21.1848345 ] ] } }
]
}
