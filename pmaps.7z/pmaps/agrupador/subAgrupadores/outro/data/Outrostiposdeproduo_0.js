var json_Outrostiposdeproduo_0 = {
"type": "FeatureCollection",
"crs": { "type": "name", "properties": { "name": "urn:ogc:def:crs:OGC:1.3:CRS84" } },
"features": [
{ "type": "Feature", "properties": { "id_pesq": "889", "titulo": "CONSTRUCAO DO PASSADO E EDUCACAO PATRIMONIAL A PARTIR DE IMAGENS FOTOGRAFICAS DE PALMAS, PR", "agrupador": "OUTRO TIPO DE PRODUCAO", "producao": "OUTRO TIPO DE PRODUCAO", "subtipo": "NAO SE APLICA", "ano": 2015.0, "autores": "SILVANO APARECIDO REDON,", "autor1": "SILVANO APARECIDO REDON", "desc_col": "FARMACIA", "desc_sub": "FARMACIA", "cdcapes_su": 40300005.0, "desc_area": "CIENCIAS DA SAUDE", "cdcapes_ar": 40000001.0, "nome_event": null, "nm_localid": "PALMAS" }, "geometry": { "type": "MultiPoint", "coordinates": [ [ -51.988773887712767, -26.481472515 ] ] } },
{ "type": "Feature", "properties": { "id_pesq": "1089", "titulo": "IV SEMINARIO INSTITUCIONAL DO PIBID - IFPR\/PALMAS", "agrupador": "OUTRO TIPO DE PRODUCAO", "producao": "OUTRO TIPO DE PRODUCAO", "subtipo": "NAO SE APLICA", "ano": 2016.0, "autores": "KATIA CILENE SILVA SANTOS CONCEICAO, SANDRA INES ADAMS ANGNES", "autor1": "SANDRA INES ADAMS ANGNES", "desc_col": "QUIMICA", "desc_sub": "QUIMICA", "cdcapes_su": 10600000.0, "desc_area": "CIENCIAS EXATAS E DA TERRA", "cdcapes_ar": 10000003.0, "nome_event": "SEMINARIO INSTITUCIONAL DO PIBID", "nm_localid": "PALMAS" }, "geometry": { "type": "MultiPoint", "coordinates": [ [ -51.988773887712767, -26.481472515 ] ] } }
]
}
