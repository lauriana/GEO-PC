﻿select tb_pesquisador.nome
	from tb_publicacao as p, tb_pesquisador
	inner join tb_pesquisador on tb_pesquisador.id_pesq = tb_publicacao.autor1
