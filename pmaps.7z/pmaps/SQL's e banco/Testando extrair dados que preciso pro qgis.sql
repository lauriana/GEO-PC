﻿select tb_publicacao.id_pesq, tb_publicacao.titulo, tb_publicacao.tipo_agrupador 
	as agrupador,  tb_publicacao.tipo_producao as producao, tb_publicacao.subtipo_producao as subtipo,
	tb_publicacao.ano, tb_pesquisador.nome as coordenador,tb_pesquisador.id_lattes, tb_pesquisador.area_titulacao,
	tb_pesquisador.titulacao, tb_colegiado.descricao as desc_col, tb_sub_area.descricao as desc_sub, 
	tb_sub_area.cod_capes as cdcapes_subarea, tb_area_conhecimento.descricao as desc_area,
	tb_area_conhecimento.cod_capes as cdcapes_area, tb_evento.nome_evento, tb_cidades.nm_localid, tb_cidades.geom
	
from tb_publicacao
inner join tb_pesquisador on (tb_publicacao.autor1 = tb_pesquisador.id_pesq)
inner join tb_colegiado on (tb_pesquisador.colegiado = tb_colegiado.id_col)
inner join tb_sub_area on (tb_colegiado.sub_area = tb_sub_area.id_subarea)
inner join tb_area_conhecimento on (tb_sub_area.area = tb_area_conhecimento.id_area)
inner join tb_evento on (tb_publicacao.evento = tb_evento.id_evento)
inner join tb_cidades on (tb_publicacao.cidade = tb_cidades.id_cidade);

----left outer no evento -----
select tb_publicacao.id_pesq, tb_publicacao.titulo, tb_publicacao.tipo_agrupador as agrupador,  tb_publicacao.tipo_producao as producao, tb_publicacao.subtipo_producao as subtipo,
	tb_publicacao.ano,tb_publicacao.autores as autores, tb_pesquisador.nome as autor1, tb_colegiado.descricao as desc_col, 
	tb_sub_area.descricao as desc_sub, tb_sub_area.cod_capes as cdcapes_subarea, tb_area_conhecimento.descricao as desc_area,
	tb_area_conhecimento.cod_capes as cdcapes_area, tb_evento.nome_evento, tb_cidades.nm_localid, tb_cidades.geom
	
from tb_publicacao
inner join tb_pesquisador on (tb_publicacao.autor1 = tb_pesquisador.id_pesq)
inner join tb_colegiado on (tb_pesquisador.colegiado = tb_colegiado.id_col)
inner join tb_sub_area on (tb_colegiado.sub_area = tb_sub_area.id_subarea)
inner join tb_area_conhecimento on (tb_sub_area.area = tb_area_conhecimento.id_area)
left outer join tb_evento on (tb_publicacao.evento = tb_evento.id_evento)
inner join tb_cidades on (tb_publicacao.cidade = tb_cidades.id_cidade) order by id_pesq;

