﻿update tb_publicacao set autores = concat(autores, '') 
	where autor1 = '138' or 
	      autor2 = '138' or 
	      autor3 = '138' or 
	      autor4 = '138' or
	      autor5 = '138';